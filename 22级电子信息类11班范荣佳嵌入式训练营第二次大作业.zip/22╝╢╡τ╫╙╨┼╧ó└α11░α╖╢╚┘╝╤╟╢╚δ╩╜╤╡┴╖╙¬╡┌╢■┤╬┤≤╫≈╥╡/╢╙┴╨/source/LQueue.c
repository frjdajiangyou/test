#include "LQueue.h"
int p = 0;
int q = 0;
void InitLQueue(LQueue* Q)
{
	if (Q == NULL)
		return;
	Node* head = (Node*)malloc(sizeof(Node));
	Q->front = Q->rear = head;
	Q->front->next = NULL;
	Q->length = 0;
}

Status IsEmptyLQueue(const LQueue* Q)
{
	if (Q->rear !=Q->front)
	{
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

Status GetHeadLQueue(LQueue* Q, void** e)
{
	if (IsEmptyLQueue(Q))
	{
		return FALSE;
	}

	*e = Q->front->next->data;
	return TRUE;

}

int LengthLQueue(LQueue* Q)
{
	return Q->length;
}

Status EnLQueue(LQueue* Q, void* data)
{
	if (Q == NULL)
		return FALSE;

	Node* newnode = (Node*)malloc(sizeof(Node));
	newnode->data= (void*)malloc(21);
	memcpy(newnode->data, data, 20);
	newnode->next = NULL;
	if (Q->rear == NULL)
		return FALSE;
	if (IsEmptyLQueue(Q))
	{
		Q->rear= newnode;
		Q->front->next = Q->rear;
		return TRUE;
	}
	Q->rear->next = newnode;
	Q->rear = newnode;
	Q->length++;
	return TRUE;
}

Status DeLQueue(LQueue* Q)
{
	if (Q == NULL)
		return FALSE;
	if (IsEmptyLQueue(Q))
		return FALSE;
	Node* cur = Q->front->next;
	Q->front->next = cur->next;
	if (Q->rear == cur)
		Q->rear = Q->front;
	free(cur);
	int i;
	for (i = 0; i < Q->length; i++)
	{
		datatype[i] = datatype[i + 1];
	}
	Q->length--;
	return TRUE;
}

void ClearLQueue(LQueue* Q)
{
	if (Q == NULL)
		return;
	if (IsEmptyLQueue(Q))
		return;
	Node* cur = Q->front->next;
	Node* nodenext = cur->next;
	while (cur != NULL)
	{
		free(cur);
		cur = nodenext;
		if(nodenext!=NULL)
		nodenext = nodenext->next;
	}
	p = 0;
	q = 0;
	int i;
	for (i = 0; i < 30; i++)
	{
		datatype[i] = 0;
	}
	Q->rear = Q->front;
	Q->length = 0;
}

Status TraverseLQueue(const LQueue* Q, void (*foo)(void* q))
{
	pprint = 0;
	if (Q == NULL)
		return FALSE;
	if (IsEmptyLQueue(Q))
		return FALSE;
	Node* cur = Q->front->next;
	while (cur!= NULL)
	{
		foo(cur->data);
		pprint++;
		cur = cur->next;
	}
	printf("\n");
	return TRUE;
}


void LPrint(void* q)
{
	if (datatype[pprint] == 'i')
	{
		printf("%d ", *(int*)q);
	}
	else if (datatype[pprint]== 'c')
	{
		printf("%s ", (char*)q);
	}
	else if (datatype[pprint] == 'f')
	{
		printf("%f ", *(float*)q);
	}
	else if (datatype[pprint] == 's')
	{
		printf("%s ", (char*)q);
	}
}

void DestoryLQueue(LQueue* Q)
{
	if (Q == NULL)
		return;
	ClearLQueue(Q);
}

void Lscanf(void**e)
{
	int command = 0;
	printf("����������Ҫ��ӵ����ͣ�");
	printf("1.����  2.�ַ���  3.������  4.�ַ���(�ַ���������10���ַ�)\n");
	scanf_s("%d", &command);
	while (command != 1 && command != 2 && command != 3&& command != 4&&(command<1||command>4))
	{
		printf("����ָ��Ϸ�������������\n");
		scanf_s("%d", &command);
	}
	if (command== 1)
	{
		datatype[p] = 'i';
		p++;
	}
	if (command == 2)
	{
		datatype[p] = 'c';
		p++;
	}
	if (command == 3)
	{
		datatype[p] = 'f';
		p++;
	}
	if (command == 4)
	{
		datatype[p] = 's';
		p++;
	}
	printf("������Ҫ����ڵ��ֵ\n");
	if (datatype[q] == 'i')
	{
		int a = 0;
		scanf_s("%d", &a);
		*e = &a;
		q++;
	}
	if (datatype[q] == 'c')
	{
		char a[11] = { 0 };
		scanf_s("%s", a, 11);
		*e = a;
		q++;
	}
	if (datatype[q] == 'f')
	{
		float a = 0;
		scanf_s("%f", &a);
		*e = &a;
		q++;
	}
	if (datatype[q] == 's')
	{
		char a[11] = { 0 };
		scanf_s("%s",a,11);
		*e = a;
		q++;
	}
}