#include <stdio.h>
#include "LinkStack.h"

Status initLStack(LinkStack* s)
{
	if (s == NULL)
		return ERROR;
	s->top = (LinkStackPtr)malloc(sizeof(StackNode));
	s->count = 0;
	s->top->next = NULL;
	return SUCCESS;
}

Status isEmptyLStack(LinkStack* s)
{
	if (s == NULL)
		return ERROR;
	if (s->count != 0)
		return ERROR;
	else
		return SUCCESS;
}
Status getTopLStack(LinkStack* s, ElemType* e)
{
	if (s == NULL)
		return ERROR;
	if (s->count == 0)
		return ERROR;
	(*e) = s->top->data;
	return SUCCESS;
}

Status clearLStack(LinkStack* s)
{
	if (s == NULL)
		return ERROR;
	LinkStack* cur = s;
	while (cur->count != 0)
	{
		cur = s->top->next;
		free(s->top);
		s->top = cur;
		s->count--;
	}
	return SUCCESS;
}

Status pushLStack(LinkStack* s, ElemType data)
{
	if (s == NULL)
		return ERROR;
	LinkStackPtr cur = (LinkStackPtr)malloc(sizeof(StackNode));
	cur->data = data;
	cur->next = s->top;
	s->top = cur;
	s->count++;
	return SUCCESS;
}

Status popLStack(LinkStack* s, ElemType* data)
{
	if (s == NULL)
		return ERROR;
	if (s->count == 0)
		return ERROR;
	LinkStackPtr cur = s->top;
	(*data) = cur->data;
	cur = cur->next;
	free(s->top);
	s->top = cur;
	s->count--;
	return SUCCESS;
}

Status LStackLength(LinkStack* s, int* length)
{
	if (s == NULL)
		return ERROR;
	(*length) = s->count;
	return SUCCESS;
}

Status destroyLStack(LinkStack* s)
{
	if (s == NULL)
		return ERROR;
	clearLStack(s);
	s->top = NULL;
	return SUCCESS;
}