#include "head.h"
//��������������
void TestMIN()
{
	FILE* fp;
	int num = createMIN();
	int N = 100;
	int* a1 = (int*)malloc(sizeof(int) * N);
	assert(a1);
	int* a2 = (int*)malloc(sizeof(int) * N);
	assert(a2);
	int* a3 = (int*)malloc(sizeof(int) * N);
	assert(a3);
	int* a4 = (int*)malloc(sizeof(int) * N);
	assert(a4);
	int* a5 = (int*)malloc(sizeof(int) * N);
	assert(a5);
	int* temp = NULL;
	int data;
	fp = fopen("MINdata.txt", "r");
	if (fp == NULL)
	{
		perror("open fail");
		return;
	}
	int i = 0;
	while (!feof)
	{
		fscanf(fp, "%d", &data);
		a1[i] = data;
		a2[i] = a1[i];
		a3[i] = a1[i];
		a4[i] = a1[i];
		a5[i] = a1[i];
		i++;
	}
	int num1 = num;
	int num2 = num;
	int num3 = num;
	int num4 = num;
	int num5 = num;
	int max = GetMax(a4, N);

	int begin1 = clock();
	while (num1--)
		InsertSort(a1, N);
	int end1 = clock();


	int begin2 = clock();
	while (num2--)
		MergeSort(a2, 0, N - 1, temp);
	int end2 = clock();

	int begin3 = clock();
	while (num3--)
		QuickSort_Recursion(a3, 0, N - 1);
	int end3 = clock();

	int begin4 = clock();
	while (num4--)
		CountSort(a4, N, max);
	int end4 = clock();

	int begin5 = clock();
	while (num5--)
		RadixCountSort(a5, N);
	int end5 = clock();

	printf("��������:%d\n", end1 - begin1);
	printf("�鲢����:%d\n", end2 - begin2);
	printf("��������:%d\n", end3 - begin3);
	printf("��������:%d\n", end4 - begin4);
	printf("������������:%d\n", end5 - begin5);

	free(a1);
	free(a2);
	free(a3);
	free(a4);
	free(a5);
	free(temp);
}
void TestMAX()
{
	int i = 0;
	int N = createMAX();
	if (N == 0)
	{
		return;
	}
	int data = 0;
	int* a1 = (int*)malloc(sizeof(int) * N);
	assert(a1);
	int* a2 = (int*)malloc(sizeof(int) * N);
	assert(a2);
	int* a3 = (int*)malloc(sizeof(int) * N);
	assert(a3);
	int* a4 = (int*)malloc(sizeof(int) * N);
	assert(a4);
	int* a5 = (int*)malloc(sizeof(int) * N);
	assert(a5);
	int* temp = NULL;
	FILE* fp;
	fp = fopen("MAXdata.txt", "r");
	if (fp == NULL)
	{
		perror("open fail");
		return;
	}
	while (!feof)
	{
		fscanf(fp, "%d", &data);
		a1[i] = data;
		a2[i] = a1[i];
		a3[i] = a1[i];
		a4[i] = a1[i];
		a5[i] = a1[i];
		i++;
	}
	fclose(fp);
	int max = GetMax(a4, N);
	int begin1 = clock();
	InsertSort(a1, N);
	int end1 = clock();

	int begin2 = clock();
	MergeSort(a2, 0, N - 1, temp);
	int end2 = clock();

	int begin3 = clock();
	QuickSort_Recursion(a3, 0, N - 1);
	int end3 = clock();

	int begin4 = clock();
	CountSort(a4, N, max);
	int end4 = clock();

	int begin5 = clock();
	RadixCountSort(a5, N);
	int end5 = clock();


	printf("InsertSort:%d\n", end1 - begin1);
	printf("MergeSort:%d\n", end2 - begin2);
	printf("QuickSort_Recursion:%d\n", end3 - begin3);
	printf("CountSort:%d\n", end4 - begin4);
	printf("RadixCountSort:%d\n", end5 - begin5);

	free(a1);
	free(a2);
	free(a3);
	free(a4);
	free(a5);
	free(temp);
}