#include "head.h"
int createMAX()
{
	FILE* fp;
	int option;
	char ch;
	int num;
	printf("��ѡ��Ҫ���ɵ�������:\n");
	printf("0.�˳� 1.1000 2.2000 3.3000\n");
	scanf("%d", &option);
	if (option == 1)
	{
		num = 1000;
	}
	else if (option == 2)
	{
		num = 2000;
	}
	else if (option == 3)
	{
		num = 3000;
	}
	else if (option == 0)
	{
		printf("�������˳�\n");
		system("pause");
		system("cls");
		return 0;
	}
	else
	{
		while ((ch = getchar()) != '\n' && ch != EOF);  //��ջ�����
		printf("ָ���������\n");
		system("pause");
		system("cls");
		return 0;
	}
	srand((unsigned int)time(NULL));//���������
	fp = fopen("MAXdata.txt", "w");
	if (fp == NULL)
	{
		perror("open fail:");
		return 0;
	}
	int tem = num;
	while (tem--)
	{
		fprintf(fp, "%d ", rand());
	}
	fclose(fp);
	printf("���ɳɹ�\n");
	system("pause");
	system("cls");
	return num;
}
int createMIN()
{
	FILE* fp;
	int option;
	char ch;
	int num;
	printf("��ѡ��Ҫ����Ĵ�����������Ĭ��Ϊ100��\n");
	printf("0.�˳� 1.1000 2.2000 3.3000\n");
	scanf("%d", &option);
	if (option == 1)
	{
		num = 1000;
	}
	else if (option == 2)
	{
		num = 2000;
	}
	else if (option == 3)
	{
		num = 3000;
	}
	else if (option == 0)
	{
		printf("�������˳�\n");
		system("pause");
		system("cls");
		return 0;
	}
	else
	{
		while ((ch = getchar()) != '\n' && ch != EOF);  //��ջ�����
		printf("ָ���������\n");
		system("pause");
		system("cls");
		return 0;
	}
	srand((unsigned int)time(NULL));//���������
	fp = fopen("MINdata.txt", "w");
	if (fp == NULL)
	{
		perror("open fail:");
		return 0;
	}
	int tem = 100;
	while (tem--)
	{
		fprintf(fp, "%d ", rand());
	}
	fclose(fp);
	printf("���ɳɹ�\n");
	system("pause");
	system("cls");
	return num;
}


int GetMax(int* a,int size)//��ȡ�����е����ֵ
{
	int i;
	int max = a[0];
	for (i = 0; i < size; i++)
	{
		if (max < a[i])
		{
			max = a[i];
		}
	}
	return max;
}



void InsertSort(int* a, int n)
{
	for (int i = 0; i < n - 1; i++)
	{
		int end = i;
		int tmp = a[end + 1];

		while (end >= 0)
		{
			if (tmp < a[end])
			{
				a[end + 1] = a[end];
				end--;
			}
			else
			{
				break;
			}
		}
		a[end + 1] = tmp;
	}
}


void MergeArray(int* a, int begin, int mid, int end, int* temp)
{
	if (begin >= end)
	{
		return;
	}
	int begin1 = begin;
	int end1 = mid;
	int begin2 = mid + 1;
	int end2 = end;
	MergeArray(a, begin1, (begin + (end - begin) / 2),end1, temp);
	MergeArray(a, begin2, (begin + (end - begin) / 2), end2, temp);
	int i = begin;
	while (begin1 <= end1 && begin2 <= end2)//��������Բ�Ϊ�գ����кϲ�
	{
		if (a[begin1] <= a[begin2])
		{
			temp[i] = a[begin1];
			i++;
			begin1++;
		}
		else
		{
			temp[i] = a[begin2];
			i++;
			begin2++;
		}
	}
	//�ж����鳤�̲�һ�µ������ʣ�����������ϲ�
	while (begin1 <= end1)
	{
		temp[i] = a[begin1];
		i++;
		begin1++;
	}
	while (begin2 <= end2)
	{
		temp[i] = a[begin2];
		i++;
		begin2++;
	}

	//���鲢���鿽������ʱ�ռ�

	memcpy(a + begin, temp + begin, (end-begin+1)*sizeof(int));

}

void MergeSort(int* a, int begin, int end, int* temp)
{
	
	temp = (int*)malloc(sizeof(int) * (end - begin + 1));
	if (temp == NULL)//�ж��ڴ������Ƿ�ɹ�
	{
		printf("�ڴ�����ʧ��\n");
		return;
	}
	MergeArray(a, 0, (begin+(end - begin)/2), end,temp);
	free(temp);
	temp = NULL;
}


void swap(int* a, int* b)
{
	if ((a != b)&&(*a!=*b))
	{
		int tem = *a;
		*a = *b;
		*b = tem;
	}

}

void QuickSort_Recursion(int*a,int begin,int end)
{
	int keyi = begin;
	int left = begin;
	int right = end;
	while (left < right)
	{
		while (left < right && a[keyi] <= a[right])
			right--;
		while (left < right && a[keyi] >= a[left])
			left++;
		if (left < right)
		{
			swap(&a[left], &a[right]);
		}
	}
	int meeti = left;
	swap(&a[keyi], &a[meeti]);
	if (begin >= end)
	{
		return;
	}
	//�������Ϊ�������֣�����ݹ�
	QuickSort_Recursion(a, begin, meeti-1);
	QuickSort_Recursion(a, meeti + 1, end);
}

void CountSort(int* a, int size, int max)
{
	int min=a[0];
	int i=0;
	for (i = 0; i < size; i++)
	{
		if (min > a[i])
		{
			min = a[i];
		}
	}
	int range = max - min + 1;
	int* count = (int*)calloc(range ,sizeof(int));
	
	if (count == NULL)
	{
		printf("�ڴ�����ʧ��\n");
		return;
	}
	for (i = 0; i < size; i++)
	{
		count[a[i] - min]++;
	}
	i = 0;
	int j;
	for (j = 0; j < range; j++)
	{
		while (count[j]--)
		{
			a[i++] = j + min;
		}
	}
	free(count);

}


void ColorSort(int* a, int size)
{
	int count[3] = { 0 };
	int i;
	for (i = 0; i < size; i++)
	{
		count[a[i]]++;
	}
	int j;
	i = 0;
	int tem = 0;
	for (i = 0; i < 3; i++)
	{
		for (j = 0; j < count[i]; j++)
		{
			a[tem++] = i;
		}
	}
}


void RadixCountSort(int* a, int size)
{
	int max = a[0];
	int min = a[0];
	int base = 1;
	for (int i = 0; i < size; i++)
	{
		if (a[i] > max)
		{
			max = a[i];
		}
		if (a[i] < min)
		{
			min = a[i];
		}
	}
	for (int i = 0; i < size; i++)
	{
		a[i] += abs(min);
	}
	int* tmp = (int*)malloc(sizeof(int) * size);
	if (tmp == NULL)
	{
		printf("�ڴ�����ʧ��\n");
		return;
	}
	while (max / base > 0)
	{
		int bucket[10] = { 0 };
		for (int i = 0; i < size; i++)
		{
			bucket[a[i] / base % 10]++;
		}

		for (int i = 1; i < 10; i++)
		{
			bucket[i] += bucket[i - 1];
		}
		for (int i = size - 1; i >= 0; i--)
		{
			tmp[bucket[a[i] / base % 10] - 1] = a[i];
			bucket[a[i] / base % 10]--;
		}
		for (int i = 0; i < size; i++)
		{
			a[i] = tmp[i];
		}
		base *= 10;
	}
	free(tmp);

	for (int i = 0; i < size; i++)
	{
		a[i] -= abs(min);
	}
}
