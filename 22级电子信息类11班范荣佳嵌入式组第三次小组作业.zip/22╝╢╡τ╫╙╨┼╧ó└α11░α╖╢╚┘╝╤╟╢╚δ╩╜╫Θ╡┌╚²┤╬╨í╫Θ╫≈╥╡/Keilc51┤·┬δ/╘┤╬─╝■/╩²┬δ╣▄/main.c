#include <REGX52.H>
unsigned char NixieTable[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f,};
void Delay1ms(unsigned int xms)
{
	unsigned char i, j;
	while(xms)
	{
		i = 2;
	j = 199;
	do
	{
		while (--j);
	} while (--i);
		xms--;
	}
	
}

void main()
{
	int i;
	while(1)
	{
		for(i=0;i<10;i++)
		{
		  P2=~NixieTable[i];
			Delay1ms(500);
		}
	}
}