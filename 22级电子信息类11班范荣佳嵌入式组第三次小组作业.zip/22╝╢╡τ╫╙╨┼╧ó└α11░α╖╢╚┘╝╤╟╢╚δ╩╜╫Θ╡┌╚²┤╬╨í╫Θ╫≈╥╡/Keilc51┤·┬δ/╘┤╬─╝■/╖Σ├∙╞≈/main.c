#include <REGX52.H>

void Delay500us()		//@12.000MHz
{
	unsigned char i;

	i = 247;
	while (--i);
}

void main()
{
		while(1)
		{
			P2_0=~P2_0;
			Delay500us();
		}
}
	