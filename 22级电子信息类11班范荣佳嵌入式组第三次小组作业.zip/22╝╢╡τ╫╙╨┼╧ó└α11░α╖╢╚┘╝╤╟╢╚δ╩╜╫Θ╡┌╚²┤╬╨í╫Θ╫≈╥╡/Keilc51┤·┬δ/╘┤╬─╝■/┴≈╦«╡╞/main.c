#include <REGX52.H>

void Delay500ms()		//@12.000MHz
{
	unsigned char i, j, k;

	i = 4;
	j = 205;
	k = 187;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

void main()
{
	unsigned char i;
	while(1)
	{
		for(i=0;i<8;i++)
		{
			P2=~(0x01<<i);
			Delay500ms();
		}	
	}
}
